#!/system/bin/sh

if [ -x /data/adb/modules/caesar_launcher/scripts/launcher.sh ]; then
  /data/adb/modules/caesar_launcher/scripts/launcher.sh stop-runtime >/dev/null 2>&1
fi

rm -rf /data/adb/caesar_launcher
