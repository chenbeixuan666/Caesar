#!/system/bin/sh

MODDIR=${0%/*}
"$MODDIR/scripts/launcher.sh" init >/dev/null 2>&1
"$MODDIR/scripts/launcher.sh" start-supervisor >/dev/null 2>&1
