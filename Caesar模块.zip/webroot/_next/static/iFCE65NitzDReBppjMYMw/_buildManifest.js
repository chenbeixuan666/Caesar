self.__BUILD_MANIFEST = {
  "/": [
    "static/chunks/1_kvka-z_a_uv.js"
  ],
  "/_error": [
    "static/chunks/0v94591ktwimi.js"
  ],
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [
      {
        "source": "/.//_next/:path+",
        "destination": "/_next/:path+"
      }
    ],
    "fallback": []
  },
  "sortedPages": [
    "/",
    "/_app",
    "/_error"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()