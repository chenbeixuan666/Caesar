__turbopack_load_page_chunks__("/_error", [
  "static/chunks/2tg08kl579oif.js",
  "static/chunks/40za3-ds6mhip.js",
  "static/chunks/turbopack-2qbhkwvpba27b.js"
])
