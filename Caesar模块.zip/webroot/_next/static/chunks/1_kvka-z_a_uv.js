__turbopack_load_page_chunks__("/", [
  "static/chunks/34z5c84muv0ov.js",
  "static/chunks/40za3-ds6mhip.js",
  "static/chunks/turbopack-3pbtbqouz1nh2.js"
])
