__turbopack_load_page_chunks__("/_app", [
  "static/chunks/0vh_gm0uyll4x.js",
  "static/chunks/40za3-ds6mhip.js",
  "static/chunks/2go_ayji6-rhc.css",
  "static/chunks/turbopack-2t781f91j7db_.js"
])
