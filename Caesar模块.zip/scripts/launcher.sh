#!/system/bin/sh

MODULE_ID="caesar_launcher"
RUNTIME_DIR="${0%/*}"
RUNTIME_DIR="${RUNTIME_DIR%/*}"
SCRIPT_FILE="$RUNTIME_DIR/scripts/launcher.sh"
if [ "$RUNTIME_DIR" = "/data/adb/modules/$MODULE_ID" ]; then
  DATA_DIR="/data/adb/$MODULE_ID"
else
  DATA_DIR="$RUNTIME_DIR/data"
fi
CONFIG_DIR="$DATA_DIR/config"
RUN_DIR="$DATA_DIR/run"
WORK_DIR="$DATA_DIR/work"
LOG_DIR="$DATA_DIR/logs"
LANGUAGE_FILE="$CONFIG_DIR/language"
UPDATE_BINARY="$RUNTIME_DIR/bin/Updata"
REQUEST_FILE="$RUN_DIR/request"
ACTIVE_TOKEN_FILE="$RUN_DIR/active.token"
TASK_PID_FILE="$RUN_DIR/task.pid"
TASK_ISOLATED_FILE="$RUN_DIR/task.isolated"
WORKER_PID_FILE="$RUN_DIR/worker.pid"
SUPERVISOR_PID_FILE="$RUN_DIR/supervisor.pid"
STATUS_FILE="$RUN_DIR/status"
INPUT_FILE="$RUN_DIR/stdin"
LOG_FILE="$LOG_DIR/launcher.log"
RUNTIME_LOG_FILE="$LOG_DIR/runtime.log"
LOG_CHUNK_SIZE=262144

init_data() {
  [ -f "$SCRIPT_FILE" ] || exit 0
  umask 077
  mkdir -p "$CONFIG_DIR" "$RUN_DIR" "$WORK_DIR" "$LOG_DIR"
  rm -f "$CONFIG_DIR/preinput.b64" "$RUN_DIR/preinput"
}

is_pid_value() {
  pid=$1
  [ -n "$pid" ] || return 1
  case "$pid" in
    *[!0-9]*) return 1 ;;
  esac
  [ "$pid" -gt 1 ] 2>/dev/null
}

read_pid() {
  cat "$1" 2>/dev/null | tr -d '\r\n '
}

pid_alive() {
  pid=$1
  is_pid_value "$pid" || return 1
  kill -0 "$pid" 2>/dev/null
}

pid_has_role() {
  pid=$1
  role=$2
  pid_alive "$pid" || return 1
  [ -r "/proc/$pid/cmdline" ] || return 1
  cmdline=$(tr '\000' ' ' < "/proc/$pid/cmdline" 2>/dev/null)
  case " $cmdline " in
    *" $SCRIPT_FILE $role "*) return 0 ;;
  esac
  return 1
}

worker_alive() {
  pid_has_role "$(read_pid "$WORKER_PID_FILE")" worker
}

supervisor_alive() {
  pid_has_role "$(read_pid "$SUPERVISOR_PID_FILE")" supervisor
}

task_alive() {
  pid_has_role "$(read_pid "$TASK_PID_FILE")" task
}

runtime_log() {
  printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" >> "$RUNTIME_LOG_FILE"
  chmod 0600 "$RUNTIME_LOG_FILE" 2>/dev/null || true
}

write_status() {
  printf '%s\n' "$1" > "$STATUS_FILE"
  chmod 0600 "$STATUS_FILE" 2>/dev/null || true
}

write_active_token() {
  printf '%s\n' "$1" > "$ACTIVE_TOKEN_FILE"
  chmod 0600 "$ACTIVE_TOKEN_FILE" 2>/dev/null || true
}

active_token_matches() {
  [ "$(cat "$ACTIVE_TOKEN_FILE" 2>/dev/null)" = "$1" ]
}

kill_term() {
  pid=$1
  pid_alive "$pid" || return 0
  kill -TERM "$pid" 2>/dev/null || true
}

kill_force() {
  pid=$1
  pid_alive "$pid" || return 0
  kill -9 "$pid" 2>/dev/null || true
}

kill_group_term() {
  pid=$1
  pid_alive "$pid" || return 0
  kill -TERM "-$pid" 2>/dev/null || true
}

kill_group_force() {
  pid=$1
  pid_alive "$pid" || return 0
  kill -KILL "-$pid" 2>/dev/null || true
}

child_pids_of() {
  parent=$1
  for stat_file in /proc/[0-9]*/stat; do
    [ -r "$stat_file" ] || continue
    pid=${stat_file%/stat}
    pid=${pid##*/}
    line=$(cat "$stat_file" 2>/dev/null) || continue
    rest=${line##*) }
    set -- $rest
    ppid=$2
    [ "$ppid" = "$parent" ] && printf '%s\n' "$pid"
  done
}

term_tree() {
  local pid=$1 child
  pid_alive "$pid" || return 0
  for child in $(child_pids_of "$pid"); do
    term_tree "$child"
  done
  kill_term "$pid"
}

kill_tree() {
  local pid=$1 child
  pid_alive "$pid" || return 0
  for child in $(child_pids_of "$pid"); do
    kill_tree "$child"
  done
  kill_force "$pid"
}

stop_task() {
  task_pid=$(read_pid "$TASK_PID_FILE")
  active_token=$(cat "$ACTIVE_TOKEN_FILE" 2>/dev/null)
  INPUT_FILE="$RUN_DIR/stdin.$active_token"
  isolated=$(cat "$TASK_ISOLATED_FILE" 2>/dev/null)
  was_active=0

  [ -f "$REQUEST_FILE" ] && was_active=1
  write_active_token "stopped-$$"
  if pid_has_role "$task_pid" task; then
    was_active=1
    if [ "$isolated" = "1" ]; then
      kill_group_term "$task_pid"
    fi
    term_tree "$task_pid"
    kill_term "$task_pid"
    sleep 1
    if [ "$isolated" = "1" ]; then
      kill_group_force "$task_pid"
    fi
    kill_tree "$task_pid"
    kill_force "$task_pid"
  fi

  rm -f "$TASK_PID_FILE" "$TASK_ISOLATED_FILE" "$REQUEST_FILE" "$INPUT_FILE"
  write_status "stopped"

}

stop_runtime() {
  stop_task
  supervisor_pid=$(read_pid "$SUPERVISOR_PID_FILE")
  worker_pid=$(read_pid "$WORKER_PID_FILE")

  if pid_has_role "$supervisor_pid" supervisor; then
    kill_term "$supervisor_pid"
  fi
  if pid_has_role "$worker_pid" worker; then
    kill_term "$worker_pid"
  fi
  sleep 1
  if pid_has_role "$supervisor_pid" supervisor; then
    kill_force "$supervisor_pid"
  fi
  if pid_has_role "$worker_pid" worker; then
    kill_force "$worker_pid"
  fi
  rm -f "$SUPERVISOR_PID_FILE" "$WORKER_PID_FILE"
}

launch_worker() {
  init_data
  if worker_alive; then
    return 0
  fi

  rm -f "$WORKER_PID_FILE"
  if command -v setsid >/dev/null 2>&1; then
    setsid /system/bin/sh "$SCRIPT_FILE" worker </dev/null >>"$RUNTIME_LOG_FILE" 2>&1 &
  else
    /system/bin/sh "$SCRIPT_FILE" worker </dev/null >>"$RUNTIME_LOG_FILE" 2>&1 &
  fi

  worker_pid=$!
  printf '%s\n' "$worker_pid" > "$WORKER_PID_FILE"
  chmod 0600 "$WORKER_PID_FILE" 2>/dev/null || true
}

start_supervisor() {
  init_data
  if supervisor_alive; then
    printf 'supervisor=%s\n' "$(read_pid "$SUPERVISOR_PID_FILE")"
    return 0
  fi

  rm -f "$SUPERVISOR_PID_FILE"
  if command -v setsid >/dev/null 2>&1; then
    setsid /system/bin/sh "$SCRIPT_FILE" supervisor </dev/null >>"$RUNTIME_LOG_FILE" 2>&1 &
  else
    /system/bin/sh "$SCRIPT_FILE" supervisor </dev/null >>"$RUNTIME_LOG_FILE" 2>&1 &
  fi

  supervisor_pid=$!
  printf '%s\n' "$supervisor_pid" > "$SUPERVISOR_PID_FILE"
  chmod 0600 "$SUPERVISOR_PID_FILE" 2>/dev/null || true
  attempts=0
  while [ "$attempts" -lt 20 ]; do
    if supervisor_alive; then
      printf 'supervisor=%s\n' "$(read_pid "$SUPERVISOR_PID_FILE")"
      return 0
    fi
    attempts=$((attempts + 1))
    sleep 0.1
  done

  runtime_log "supervisor start failed pid=$supervisor_pid"
  rm -f "$SUPERVISOR_PID_FILE"
  printf '%s\n' "supervisor=0"
  return 75
}

supervisor_loop() {
  init_data
  printf '%s\n' "$$" > "$SUPERVISOR_PID_FILE"
  chmod 0600 "$SUPERVISOR_PID_FILE" 2>/dev/null || true
  trap 'rm -f "$SUPERVISOR_PID_FILE"; exit 0' INT TERM EXIT

  while [ -f "$SCRIPT_FILE" ]; do
    launch_worker
    sleep 2
  done
}

log_size() {
  if [ -f "$LOG_FILE" ]; then
    wc -c < "$LOG_FILE" 2>/dev/null | tr -d ' '
  else
    printf '0'
  fi
}

log_chunk() {
  offset=$1
  case "$offset" in
    ''|*[!0-9]*) offset=0 ;;
  esac

  size=$(log_size)
  case "$size" in
    ''|*[!0-9]*) size=0 ;;
  esac

  if [ "$offset" -gt "$size" ]; then
    offset=0
  fi

  count=$((size - offset))
  if [ "$count" -gt "$LOG_CHUNK_SIZE" ]; then
    count=$LOG_CHUNK_SIZE
  fi

  start=$((offset + 1))
  offset=$((offset + count))
  printf 'offset=%s\n' "$offset"
  printf 'size=%s\n' "$size"
  printf 'dataB64='
  if [ "$count" -gt 0 ]; then
    tail -c +"$start" "$LOG_FILE" 2>/dev/null | head -c "$count" | base64 | tr -d '\n'
  fi
  printf '\n'
}

launch_update() {
  init_data
  if ! supervisor_alive && ! worker_alive; then
    printf '%s\n' "service=0"
    return 75
  fi

  stop_task

  language=$1
  case "$language" in zh|en|vi|system) ;; *) return 64 ;; esac
  [ -x "$UPDATE_BINARY" ] || { printf 'error=missing-updater\n'; return 66; }
  command -v timeout >/dev/null 2>&1 || { printf 'error=missing-timeout\n'; return 69; }
  token="$(date '+%s')-$$"
  printf '%s' "$language" > "$LANGUAGE_FILE"
  INPUT_FILE="$RUN_DIR/stdin.$token"
  mkfifo -m 0600 "$INPUT_FILE" || return 74

  : > "$LOG_FILE"
  chmod 0600 "$LOG_FILE" 2>/dev/null || true
  write_active_token "$token"
  write_status "queued"
  printf '%s\n' "$token" > "$REQUEST_FILE"
  chmod 0600 "$REQUEST_FILE" 2>/dev/null || true
  printf 'queued=%s\n' "$token"
}

launch_task() {
  token=$1
  [ -n "$token" ] || return 0
  active_token_matches "$token" || return 0
  if task_alive; then
    return 0
  fi

  if command -v setsid >/dev/null 2>&1; then
    setsid /system/bin/sh "$SCRIPT_FILE" task "$token" </dev/null >/dev/null 2>&1 &
    isolated=1
  else
    /system/bin/sh "$SCRIPT_FILE" task "$token" </dev/null >/dev/null 2>&1 &
    isolated=0
  fi

  task_pid=$!
  printf '%s\n' "$task_pid" > "$TASK_PID_FILE"
  printf '%s\n' "$isolated" > "$TASK_ISOLATED_FILE"
  chmod 0600 "$TASK_PID_FILE" "$TASK_ISOLATED_FILE" 2>/dev/null || true
}

task_process() {
  token=$1
  init_data
  [ -n "$token" ] || exit 64
  active_token_matches "$token" || exit 0
  printf '%s\n' "$$" > "$TASK_PID_FILE"
  chmod 0600 "$TASK_PID_FILE" 2>/dev/null || true

  on_task_term() {
    if active_token_matches "$token"; then
      write_status "exited 143"
      rm -f "$TASK_PID_FILE" "$TASK_ISOLATED_FILE" "$INPUT_FILE"
    fi
    exit 143
  }
  trap on_task_term INT TERM

  INPUT_FILE="$RUN_DIR/stdin.$token"
  [ -p "$INPUT_FILE" ] || exit 74

  export PATH="/data/adb/ksu/bin:/system/bin:/system/xbin:/vendor/bin:/odm/bin:/product/bin:/apex/com.android.runtime/bin:/apex/com.android.art/bin"
  export ANDROID_ROOT="/system"
  export ANDROID_DATA="/data"
  unset LD_PRELOAD

  if ! cd "$WORK_DIR"; then
    if active_token_matches "$token"; then
      write_status "exited 1"
      rm -f "$TASK_PID_FILE" "$TASK_ISOLATED_FILE" "$INPUT_FILE"
    fi
    exit 1
  fi

  export CAESAR_LAUNCHER_LANGUAGE="$(cat "$LANGUAGE_FILE")"
  export TERM="dumb"
  exec 3<> "$INPUT_FILE" || exit 74
  write_status "running"
  "$UPDATE_BINARY" <&3 3>&- >> "$LOG_FILE" 2>&1
  code=$?
  if active_token_matches "$token"; then
    write_status "exited $code"
    rm -f "$TASK_PID_FILE" "$TASK_ISOLATED_FILE" "$INPUT_FILE"
  fi
  exit "$code"
}

worker_loop() {
  init_data
  printf '%s\n' "$$" > "$WORKER_PID_FILE"
  chmod 0600 "$WORKER_PID_FILE" 2>/dev/null || true
  trap 'rm -f "$WORKER_PID_FILE"; exit 0' INT TERM EXIT

  while [ -f "$SCRIPT_FILE" ]; do
    token=$(cat "$REQUEST_FILE" 2>/dev/null)
    if [ -n "$token" ]; then
      rm -f "$REQUEST_FILE"
      launch_task "$token"
    fi
    sleep 1
  done
}

print_status() {
  init_data
  task_pid=$(read_pid "$TASK_PID_FILE")
  status=$(cat "$STATUS_FILE" 2>/dev/null)

  if task_alive; then
    printf 'running pid=%s\n' "$task_pid"
  else
    if [ -n "$task_pid" ] && [ "$status" = "running" ]; then
      status="exited -1"
      write_status "$status"
    fi
    if [ "$status" != "queued" ]; then
      rm -f "$TASK_PID_FILE" "$TASK_ISOLATED_FILE"
    fi
    printf '%s\n' "stopped"
    case "$status" in
      queued|running)
        printf '%s\n' "queued=1"
        ;;
      exited\ *)
        printf 'exit=%s\n' "${status#exited }"
        ;;
    esac
  fi

  printf 'token=%s\n' "$(cat "$ACTIVE_TOKEN_FILE" 2>/dev/null)"
  printf 'state=%s\n' "$status"
  if worker_alive; then
    printf 'worker=%s\n' "$(read_pid "$WORKER_PID_FILE")"
  else
    printf '%s\n' "worker=0"
  fi
  if supervisor_alive; then
    printf 'supervisor=%s\n' "$(read_pid "$SUPERVISOR_PID_FILE")"
  else
    printf '%s\n' "supervisor=0"
  fi
}

case "$1" in
  init)
    init_data
    ;;
  load)
    init_data
    printf 'language=%s\n' "$(cat "$LANGUAGE_FILE" 2>/dev/null)"
    ;;
  run)
    launch_update "$2"
    ;;
  input)
    init_data
    token=$2
    case "$token" in ''|*[!0-9-]*) exit 64 ;; esac
    active_token_matches "$token" && task_alive || exit 75
    [ "$(cat "$STATUS_FILE")" = "running" ] || exit 75
    INPUT_FILE="$RUN_DIR/stdin.$token"
    [ -p "$INPUT_FILE" ] || exit 75
    [ "${#3}" -le 4096 ] || exit 64
    printf '%s' "$3" | timeout 2 /system/bin/sh -c 'base64 -d > "$1"' sh "$INPUT_FILE" || exit 74
    active_token_matches "$token" || exit 75
    printf '%s' "$3" | base64 -d >> "$LOG_FILE" || exit 74
    ;;
  stop)
    init_data
    stop_task
    ;;
  status)
    print_status
    ;;
  log)
    log_chunk "$2"
    ;;
  poll)
    print_status
    log_chunk "$2"
    ;;
  clear-log)
    init_data
    : > "$LOG_FILE"
    chmod 0600 "$LOG_FILE" 2>/dev/null || true
    ;;
  start-supervisor)
    start_supervisor
    ;;
  start-worker)
    start_supervisor
    ;;
  stop-runtime)
    stop_runtime
    ;;
  stop-worker)
    stop_runtime
    ;;
  supervisor)
    supervisor_loop
    ;;
  worker)
    worker_loop
    ;;
  task)
    task_process "$2"
    ;;
  *)
    exit 64
    ;;
esac
