#!/system/bin/sh

set_perm "$MODPATH/action.sh" 0 0 0755
set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/uninstall.sh" 0 0 0755
set_perm "$MODPATH/scripts/launcher.sh" 0 0 0755

set_perm "$MODPATH/bin/Updata" 0 0 0755
